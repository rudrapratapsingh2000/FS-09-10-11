package com.URLHit;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UrlHitApplication {

	public static void main(String[] args) {
		SpringApplication.run(UrlHitApplication.class, args);
	}

}
