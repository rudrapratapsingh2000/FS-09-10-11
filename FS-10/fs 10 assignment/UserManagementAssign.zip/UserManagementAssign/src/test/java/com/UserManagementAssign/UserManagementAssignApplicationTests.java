package com.UserManagementAssign;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserManagementAssignApplicationTests {

	@Test
	void contextLoads() {
	}

}
