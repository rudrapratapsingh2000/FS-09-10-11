package com.Restaurant;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestaurantModelApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestaurantModelApplication.class, args);
	}

}
