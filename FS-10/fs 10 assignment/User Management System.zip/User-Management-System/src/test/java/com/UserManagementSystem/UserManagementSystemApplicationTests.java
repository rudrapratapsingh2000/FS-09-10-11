package com.UserManagementSystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserManagementSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
