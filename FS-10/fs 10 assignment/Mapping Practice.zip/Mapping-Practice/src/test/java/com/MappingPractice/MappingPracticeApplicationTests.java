package com.MappingPractice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MappingPracticeApplicationTests {

	@Test
	void contextLoads() {
	}

}
