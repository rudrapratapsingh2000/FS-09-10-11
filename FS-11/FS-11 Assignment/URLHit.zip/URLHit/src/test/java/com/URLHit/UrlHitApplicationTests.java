package com.URLHit;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UrlHitApplicationTests {

	@Test
	void contextLoads() {
	}

}
