package com.UserManagementAssign;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UserManagementAssignApplication {

	public static void main(String[] args) {
		SpringApplication.run(UserManagementAssignApplication.class, args);
	}

}
